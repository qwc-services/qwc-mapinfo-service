--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: contact; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.contact (id, type, id_organisation, name, street, house_no, zip, city, country_code) FROM stdin;
1	person	\N	test	\N	\N	\N	\N	\N
\.


--
-- Data for Name: contact_role; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.contact_role (id, type) FROM stdin;
\.


--
-- Data for Name: organisation; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.organisation (id, unit, abbreviation) FROM stdin;
\.


--
-- Data for Name: person; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.person (id, function, email, phone) FROM stdin;
1	GDI	\N	\N
\.


--
-- Data for Name: resource_contact; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.resource_contact (id, id_contact_role, id_contact, gdi_oid_resource) FROM stdin;
\.


--
-- Data for Name: background_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.background_layer (gdi_oid, name, description, qgis_datasource, qwc2_bg_layer_name, qwc2_bg_layer_config, thumbnail_image) FROM stdin;
6	Grundkarte	Grundkarte WMS	contextualWMSLegend=0&crs=EPSG:2056&dpiMode=7&featureCount=10&format=image/png&layers=Grundkarte&styles=&url=https://geoweb.so.ch/wms/grundbuchplan	Grundkarte	{\n  "name": "Grundkarte",\n  "title": "Grundkarte",\n  "type": "wms",\n  "url": "https://geoweb.so.ch/wms/grundbuchplan",\n  "thumbnail": "img/mapthumbs/default.jpg"\n}	\N
\.


--
-- Data for Name: data_source; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_source (gdi_oid, name, description, connection, connection_type) FROM stdin;
1	testgeodb	Test GeoDB	postgresql://sogis_test:sogis_test@localhost:5440/testgeodb	database
\.


--
-- Data for Name: data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set (gdi_oid, name, description, gdi_oid_data_source, data_set_name) FROM stdin;
\.


--
-- Data for Name: data_set_view; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_view (gdi_oid, name, description, gdi_oid_data_set, geometry_column) FROM stdin;
\.


--
-- Data for Name: data_set_edit; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_edit (gdi_oid, name, description, gdi_oid_data_set_view) FROM stdin;
\.


--
-- Data for Name: data_set_search; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_search (gdi_oid, name, description, gdi_oid_data_set_view, title, text_attr, label_attr, query_clause) FROM stdin;
\.


--
-- Data for Name: data_set_view_attributes; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_view_attributes (gdi_oid, name, description, gdi_oid_data_set_view, alias, displayfield, attribute_order) FROM stdin;
\.


--
-- Data for Name: template; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template (gdi_oid, name, description, type) FROM stdin;
\.


--
-- Data for Name: template_info; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_info (gdi_oid, info_template, template_filename, info_type, info_sql, info_module) FROM stdin;
\.


--
-- Data for Name: template_jasper; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_jasper (gdi_oid, report_filename, uploaded_report) FROM stdin;
\.


--
-- Data for Name: ows_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.ows_layer (gdi_oid, name, description, gdi_oid_info_template, gdi_oid_object_sheet, type, title, legend_image, legend_filename, ows_metadata, layer_transparency) FROM stdin;
2	somap	Root-Layer für WMS	\N	\N	group	SOMAP	\N	\N	\N	0
4	somap	Root-Layer für WFS	\N	\N	group	SOMAP	\N	\N	\N	0
\.


--
-- Data for Name: ows_layer_group; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.ows_layer_group (gdi_oid, facade) FROM stdin;
2	f
4	f
\.


--
-- Data for Name: group_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.group_layer (id, gdi_oid_group_layer, gdi_oid_sub_layer, layer_order, layer_active) FROM stdin;
\.


--
-- Data for Name: wms_wfs; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.wms_wfs (gdi_oid, name, description, gdi_oid_root_layer, ows_type, ows_metadata) FROM stdin;
3	somap	WMS des Kt. Solothurn	2	WMS	\N
5	somap	WFS des Kt. Solothurn	4	WFS	\N
\.


--
-- Data for Name: map; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.map (gdi_oid, name, description, gdi_oid_wms_wfs, gdi_oid_default_bg_layer, title, initial_extent, initial_scale, thumbnail_image) FROM stdin;
7	default	Standardkarte	3	6	Standardkarte	2590000, 1210000, 2650000, 1270000	\N	\N
\.


--
-- Data for Name: map_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.map_layer (id, gdi_oid_map, gdi_oid_ows_layer, layer_order, layer_active, layer_transparency) FROM stdin;
\.


--
-- Data for Name: module; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.module (gdi_oid, name, description, url) FROM stdin;
\.


--
-- Data for Name: module_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.module_data_set (gdi_oid_module, gdi_oid_data_set_view) FROM stdin;
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.service (gdi_oid, name, description, url, specific_source) FROM stdin;
\.


--
-- Data for Name: module_service; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.module_service (gdi_oid_module, gdi_oid_service) FROM stdin;
\.


--
-- Data for Name: ows_layer_data; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.ows_layer_data (gdi_oid, gdi_oid_data_set_view, qgs_style, uploaded_qml) FROM stdin;
\.


--
-- Data for Name: service_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.service_data_set (gdi_oid_service, gdi_oid_data_set_view) FROM stdin;
\.


--
-- Data for Name: service_module; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.service_module (gdi_oid_service, gdi_oid_module) FROM stdin;
\.


--
-- Data for Name: template_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_data_set (gdi_oid_template_jasper, gdi_oid_data_set) FROM stdin;
\.


--
-- Data for Name: template_ows_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_ows_layer (gdi_oid_template_jasper, gdi_oid_ows_layer) FROM stdin;
\.


--
-- Data for Name: template_qgis; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_qgis (gdi_oid, qgs_print_layout, uploaded_qpt, map_width, map_height, print_labels) FROM stdin;
\.


--
-- Data for Name: transformation; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.transformation (gdi_oid, name, description, gdi_oid_target_data_set) FROM stdin;
\.


--
-- Data for Name: transformation_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.transformation_data_set (gdi_oid_transformation, gdi_oid_data_set) FROM stdin;
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam."group" (id, name, description) FROM stdin;
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.role (id, name, description) FROM stdin;
1	test	Test Role
\.


--
-- Data for Name: group_role; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.group_role (id_group, id_role) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam."user" (id, name, description) FROM stdin;
1	test	Test User
\.


--
-- Data for Name: group_user; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.group_user (id_group, id_user) FROM stdin;
\.


--
-- Data for Name: resource_permission; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.resource_permission (id, id_role, gdi_oid_resource, priority, write) FROM stdin;
1	1	1	0	f
2	1	2	0	f
3	1	3	0	f
4	1	4	0	f
5	1	5	0	f
6	1	6	0	f
7	1	7	0	f
\.


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.user_role (id_user, id_role) FROM stdin;
1	1
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: sogis_test
--

COPY public.alembic_version (version_num) FROM stdin;
\.


--
-- Data for Name: permalinks; Type: TABLE DATA; Schema: public; Owner: sogis_test
--

COPY public.permalinks (data, key, date) FROM stdin;
\.


--
-- Name: component_contact_id_seq; Type: SEQUENCE SET; Schema: contacts; Owner: sogis_test
--

SELECT pg_catalog.setval('contacts.component_contact_id_seq', 1, false);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: contacts; Owner: sogis_test
--

SELECT pg_catalog.setval('contacts.contact_id_seq', 1, false);


--
-- Name: contact_role_id_seq; Type: SEQUENCE SET; Schema: contacts; Owner: sogis_test
--

SELECT pg_catalog.setval('contacts.contact_role_id_seq', 1, false);


--
-- Name: gdi_oid_seq; Type: SEQUENCE SET; Schema: gdi_knoten; Owner: sogis_test
--

SELECT pg_catalog.setval('gdi_knoten.gdi_oid_seq', 7, true);


--
-- Name: group_layer_id_seq; Type: SEQUENCE SET; Schema: gdi_knoten; Owner: sogis_test
--

SELECT pg_catalog.setval('gdi_knoten.group_layer_id_seq', 1, false);


--
-- Name: map_layer_id_seq; Type: SEQUENCE SET; Schema: gdi_knoten; Owner: sogis_test
--

SELECT pg_catalog.setval('gdi_knoten.map_layer_id_seq', 1, false);


--
-- Name: group_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.group_id_seq', 1, false);


--
-- Name: resource_permission_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.resource_permission_id_seq', 7, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.role_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.user_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

