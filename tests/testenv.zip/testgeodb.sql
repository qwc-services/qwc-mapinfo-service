--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--




--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--




SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: test_mapinfo; Type: TABLE; Schema: public; Owner: sogis_test
--

CREATE TABLE public.test_mapinfo (
    t_id integer NOT NULL,
    gemeindename character varying(100) NOT NULL,
    bfs_nr integer NOT NULL,
    geometrie public.geometry(Polygon,2056)
);


ALTER TABLE public.test_mapinfo OWNER TO sogis_test;

--
-- Name: test_mapinfo_t_id_seq; Type: SEQUENCE; Schema: public; Owner: sogis_test
--

CREATE SEQUENCE public.test_mapinfo_t_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.test_mapinfo_t_id_seq OWNER TO sogis_test;

--
-- Name: test_mapinfo_t_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: sogis_test
--

ALTER SEQUENCE public.test_mapinfo_t_id_seq OWNED BY public.test_mapinfo.t_id;


--
-- Name: test_mapinfo t_id; Type: DEFAULT; Schema: public; Owner: sogis_test
--

ALTER TABLE ONLY public.test_mapinfo ALTER COLUMN t_id SET DEFAULT nextval('public.test_mapinfo_t_id_seq'::regclass);


--
-- Data for Name: test_mapinfo; Type: TABLE DATA; Schema: public; Owner: sogis_test
--

COPY public.test_mapinfo (t_id, gemeindename, bfs_nr, geometrie) FROM stdin;
1	Gemeinde 1	1000	0103000020080800000100000007000000709ACCBF269F93C000805E3E5D9620C0606B5D9A080379C0DAB592E8EA82B0403AF3EE99D5C5C340A87079FBCB03AE4015F69F32A504C240989703BEB271A1C0405A6F5855D76840708F77771875A6C0709ACCBF269F93C000805E3E5D9620C0709ACCBF269F93C000805E3E5D9620C0
2	Gemeinde 2	2000	01030000200808000001000000060000005CC1B8ACE93DD2400005D207DB5AB4401C097A8CE898DA4060CA6E765157AB40B0B2BC2D0744DB402053F8D73C72BEC0286153F91BEDD840F072D9596F93C6C0B4C43EAED7A1AF404072A051034497405CC1B8ACE93DD2400005D207DB5AB440
\.


--
-- Name: test_mapinfo_t_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sogis_test
--

SELECT pg_catalog.setval('public.test_mapinfo_t_id_seq', 2, true);


--
-- Name: test_mapinfo mopublic_gemeindegrenze_pkey; Type: CONSTRAINT; Schema: public; Owner: sogis_test
--

ALTER TABLE ONLY public.test_mapinfo
    ADD CONSTRAINT mopublic_gemeindegrenze_pkey PRIMARY KEY (t_id);


--
-- PostgreSQL database dump complete
--

